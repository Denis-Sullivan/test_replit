# # хороший гайд по исключениям https://younglinux.info/python/exceptions
# # хорошее описание типов исключений https://pythonworld.ru/tipy-dannyx-v-python/isklyucheniya-v-python-konstrukciya-try-except-dlya-obrabotki-isklyuchenij.html

# a = 100
# b = 0
# budget = "2795000"

# # блок исключения полностью
# try:
#   print(a/b)
# # except ZeroDivisionError:
# except (ZeroDivisionError, TypeError) as e:
#   print("Деление на ноль")
#   print(e)
# except Exception as e:
#   print(e)
# else:
#   print("Все прошло успешно")
# finally:
#   print("Этот текст напечатается в любом случае")
# # либо
# # except (ZeroDivisionError, TypeError) as e:
# #   print(e)

# # два стиля программирования
# # 1) мы можем проверять тип данных
# if type(budget) == int:
#   if budget < 3000000:
#     print("Этого нам хватит на покупку квартиры")
# else:
#   print("Это не число!")
# # 2) либо упаковать эту конструкцию в блок отлова исключений
# try:
#   if budget < 3000000:
#     print("Этого нам хватит на покупку квартиры")
# except TypeError as e:
#   print(e)
  
# # небольшой заброс в PEP8: на самом деле типы напрямую сравнивать не советуют, т.е.
# # лучше не писать так: if type(obj) is type(1) или так: if type(budget) == int
# # а правильно через isinstance
# if isinstance(budget, int):
# 	print("Да, на входе число, можно смело оценивать наши бюджетные возможности")

# # как вызвать исключение вручную
# try:
#   raise Exception("Наше тестовое исключение")
# except:
#   print("Мы поймали свое собственное исключение. Ура!")

# про assert
temperature = -1
assert (temperature > 20), "Лето еще не началось :("

# # классы исключений пользователя
# class MyNewException(Exception):
#     print("Мое тестовое исключение")
# try:
#   raise MyNewException("")
# except:
#   print("Мы поймали свое собственное исключение. Ура!")

